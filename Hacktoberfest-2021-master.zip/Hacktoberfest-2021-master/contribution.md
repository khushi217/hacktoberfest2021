# Make a new branch other than master using `
```git checkout -b branch_name```

## Open the New issues sections and check the issues that you think suits you.

### Also open "this folder" and include the link of good developer resources and also have a look at the existing resources that you think are useful for you and keep exploring .
## we are working on making this as a web app and need an update on that with you all so for Hacktoberfest 2020 we want it to be completed by Mid October and for the same have a look at the existing isssues.

# OR

### Add mini projects on DSA or some projects or problems you have tried but try not to repeat them or add any good projects that are beginners friendly

# PRs made directly to contributors list without adding any useful Resource / Project / Solving Issues will be marked as invalid/spam .

### Please just don't do it just for the heck of a T-shirt do it to learn and get experience on how to make a PR !!!!!!!

### Don't worry newcomers!! Make this your first step to development and open source. Get the confidence you require!!
