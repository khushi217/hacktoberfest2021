package arrays;

public class TwoDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
                
		//int a[][] = new int [5][3];
		
		int b[][] = {
				      {1,3,5,7},
				      {2,4,6},
				      {9,10,11,12,13}
		
		
		                  };
		   System.out.println(b[0][1]);
		
		
		
	}

}
