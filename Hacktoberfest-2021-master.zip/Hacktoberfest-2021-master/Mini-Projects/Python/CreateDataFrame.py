import pandas as pd
dict={'Name':['Silvi','Shreya','Shaina','Shan'],'Roll No':[72,70,45,29],'Eng_Marks':[96,67,89,74],'Maths_Marks':[99,88,77,67]}
df=pd.DataFrame(dict)
print(df)
