first = input("Enter first name")
last = input("Enter last name")
print(first[::-1]+" " +last[::-1])
