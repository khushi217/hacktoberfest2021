def fib(n):
  #BASE CASE
  if n==0 or n==1:
    return
  #RECURSIVE CASE
  else:
    return fib(n-1)+fib(n-2)
#call using function with parameter
