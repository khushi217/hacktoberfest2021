i=input('Enter the value of i:')
j=input('Enter the value of j:')
k=input('Enter the value of k:')

if i>j and i>k:
    print("i is Greatest")

elif j>i and j>k: 
    print("j is Greatest")   

else:
    print("k is Greatest")