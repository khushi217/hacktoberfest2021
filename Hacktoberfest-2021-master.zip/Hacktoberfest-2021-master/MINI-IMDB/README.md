IT IS A MINI-IMDB PROJECT THAT PROVIDES INFORMATION ABOUT ANY MOVIE OR TV SERIES WHEN SEARCHED.

READ THE DOCUMENTATION FIRST, THEN MOVE ON TO THE SOURCE CODE AS DOCUMENTATION WILL BRIEF YOU ABOUT THE PYTHON MODULE, DATA STRUCTURES USED AND ALSO HOW TO WORK THROUGH THIS PROGRAM.

For running this code you have to download IMDbPy package from google. IMDbPY is a Python package useful to retrieve and manage the data of the IMDb movie database about movies, people,
characters and companies.Platform-independent and written in Python 3 it can retrieve data from both the IMDb’s web server and a local copy of the whole database.
IMDbPY package can be very easily used by programmers and developers to provide access to the IMDb’s data to their programs.

For understanding this project you need to have a basic knowledge about python, definition of database, module, instances and lists.

While running the code it asks for a movie or tv series name. After you enter the movie or a  tv series name it returns a list of movies or tv series with its id which are related to the
movies or tv series you entered. Since every movie or tv series has a unique id, this program asks for a id for the particular movie or tv series you want to search after you enter the id
it reuturns plot, cast name, director of movie or writer of a tv series, rating, genre. 
