

print('Hello World!')

#fazendo um print com formatação, variáveis e função.

def main():
  mensagem = input('Digite a mensagem de apresentação : ')
  
  print(f' A mensagem digitada foi : {mensagem} !')
main()  

