(function () {
  "use strict";

  $(function () {
    $(".menu-container").load("index.html");
  });
})();
