# You can make PRs on these Repos for more swags 

* [Hacktoberfest-swag](https://github.com/benbarth/hacktoberfest-swag)

* [Hacktoberfest 2019 Swag List](https://github.com/crweiner/hacktoberfest-swag-list/blob/master/README.md)

* [Awesome-hacktoberfest-2019](https://github.com/OtacilioN/awesome-hacktoberfest-2019)

* [Up for Grabs](https://up-for-grabs.net/#/)
