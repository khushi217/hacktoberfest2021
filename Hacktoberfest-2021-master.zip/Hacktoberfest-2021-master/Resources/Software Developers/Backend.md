#### The following are the Technologies that are used to create Backend of various kinds of applications. Below is the list:-
1. [JavaScript](https://glossarytech.com/terms/javascript)
2. [PHP](https://glossarytech.com/terms/php)
3. [Ruby](https://glossarytech.com/terms/ruby)
4. [Java](https://glossarytech.com/terms/java)
5. [C#(.Net)](https://glossarytech.com/terms/c-net)
6. [Python](https://glossarytech.com/terms/python)
7. [C](https://glossarytech.com/terms/c)
8. [C++](https://glossarytech.com/terms/c_plus_plus)
9. [Scala](https://glossarytech.com/terms/scala)
10. [Golang](https://glossarytech.com/terms/golang)
11. [Functional Programming](https://glossarytech.com/terms/functional-programming-fp)
12. [Other Programming Languages](https://glossarytech.com/terms/other-programming_languages)

#### Learning Resources
 1. [Javascript](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guidehttps://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide)
 2. [PHP](https://cloud.google.com/php/getting-started)
3. [Ruby](https://cloud.google.com/ruby/getting-started)
4. [Java](https://cloud.google.com/java/getting-started)
5. [C#(.Net)](https://dotnet.microsoft.com/learn/csharp)
6. [Python](https://developers.google.com/edu/python)

##### For More Information : [GlossaryTech](https://glossarytech.com/)

